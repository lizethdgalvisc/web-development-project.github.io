# sublimetext_spanish

Spanish localization of Sublime Text 3 menus.


## Installation

- Download the content of this package from Github as a ZIP file ("Clone or download" button, and then "Download ZIP"), open it, and extract the content inside the sublimetext_spanish-[version] folder to your Sublime Text 3 Packages directory (Preferences -> Browse Packages...).


## Uninstall

- Delete both "Default" and "User/Spanish Localization" directory in Packages directory.


---
Traducción al castellano de los menús de Sublime Text 3.


## Instalación

- Descarga el paquete desde GitHub como un archivo ZIP (botón "Clone or download", y después "Download ZIP"), ábrelo y extrae todo el contenido de la carpeta sublimetext_spanish-[version] al directorio Packages de Sublime Text 3 (Preferences -> Browse Packages...).


## Desinstalación

- Borra los directorios "Default" y "User/Spanish Localization" del directorio Packages.
