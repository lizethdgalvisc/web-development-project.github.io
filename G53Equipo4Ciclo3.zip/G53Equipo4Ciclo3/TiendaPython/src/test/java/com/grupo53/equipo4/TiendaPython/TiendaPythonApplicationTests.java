package com.grupo53.equipo4.TiendaPython;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaPythonApplicationTests {

	@Test
	void contextLoads() {
	}

}
