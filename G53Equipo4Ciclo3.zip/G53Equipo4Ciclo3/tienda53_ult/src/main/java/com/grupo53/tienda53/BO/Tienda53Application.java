package com.grupo53.tienda53.BO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tienda53Application {

	public static void main(String[] args) {
		SpringApplication.run(Tienda53Application.class, args);
	}

}